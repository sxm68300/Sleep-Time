window.mcwidget = {
    "appId": "532160876956612",
    "pageId": "100766638134365",
    "page_name": "Sleepyti.me",
    "fb_page_id": "100766638134365",
    "widget_phone": null,
    "sms_channel_connected": false,
    "widgets": [{
        "widget_id": 8912520,
        "page_id": "100766638134365",
        "widget_type": "landing",
        "status": "active",
        "name": "Example Landing",
        "data": [],
        "channel": "facebook",
        "ts_created": 1578752669
    }],
    "widgetLocale": "en_US",
    "defaultSize": 0,
    "fbSDKVersion": "v12.0",
    "whitelist": ["e04a45f0a505569fddc714decd22a84e8cb421b628b371dd70f2ca7035eac346", "f2cbfeda670dc91d10651057f2d9c1f9010175cf28059cfc43337b7d2c6f3f4d", "36d89a1ba8cf52036f81a963c230938b18519267ee2a0e7203de79da8f03be17", "de29b11964505ec28e3bd55d26bd496bf5b82f988eb83550dfdb577b985f35a1", "733305902c547d0fa210536efbed074b3da1b436384f3ca43d6b378eb06ffd14", "651683b3600692c7a442d5360f5afc5ccec2a9c5988c5d7a29d11953723f60c5", "b307d001343fa00ba913d1cafad33a2e87bcb7b6d97f2094b4e48a63eebaab86"],
    "smsModalConsentText": "Please note that by typing in your phone number in the field above you are agreeing to receive autodialed personal and marketing text messages to your mobile number. Consent is not required for purchase. Message and data rates may apply. Reply “STOP” by SMS to cancel."
};


(function(d, s, id) {
    var host = 'mccdn.me';

    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) {
        return;
    }
    js = d.createElement(s);
    js.id = id;
    js.src = '//' + host + 'widget.js';
    fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'mcwidget-core'));